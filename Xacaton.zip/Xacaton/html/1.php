 <?php
	header("Access-Control-Allow-Origin: *");?>
	</head>
	<body>
	    <script>function fdd() {
    alerts.logtime('<div style="width: 100%;height: 100%;"><form id="contact_form" action="mail.php" method="POST"><br><label>Имя</label><br><input name="name" type="text"><br><label>E-Mail</label><br><input name="email" type="text"><br><label>Сообщение</label><br><textarea name="message" rows="5" cols="25"></textarea><br><input class="btn" name="submit" value="Отправить" type="submit"></form></div>');
}</script>
	    <canvas></canvas>
    <div class="content"><!--Все вкладки-->
        <div id="2" class="TABS" style="width: 100%;"><!--Меню-->
        <button class="btn" onclick="af()">Афиши</button>
            <button class="btn" onclick="karta()">Карты</button>
            <button class="btn" onclick="fdd()">Связаться с библиотекарем</button>
            <div class="ssssss3"><button onclick=" about()" class="btn">О нас</button></div>
        </div><!--Меню-->
        
        <div id="1" class="content TABS" style="displey:none;overflow: hidden;"><!--Афиши-->
            <div style="width: 100%;height: fit-content;background: #bbb9bd;    display: flex;justify-content: center;align-items: center;">
                <!--<img src="img/logo.svg" style="width: fit-content;height: fit-content;">--></div>
        <div id="news"></div>
        
        </div><!--Афиши--> 
    </div><!--Все вкладки-->  
<div class="menu"><!--Панель-->
            <div class="form_radio_btn" onclick="showHide(1)">
	        <input id="radio-1" type="radio" name="radio" value="1" checked>
	        <label for="radio-1">Новости</label>
      </div>
      <div class="form_radio_btn" onclick="showHide(2)">
	        <input id="radio-2" type="radio" name="radio" value="2">
	        <label for="radio-2">Дополнительно</label>
      </div>
</div><!--Панель-->
</body>
</html>







	<script>
// canvas setup
const canvas = document.querySelector('canvas');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
const ctx = canvas.getContext('2d');

// watch for browser resizing, reinitialize stars
window.addEventListener('resize', function() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  init();
});

function Star(x, y, width, speed) {
  this.x = x;
  this.y = y;
  this.width = width;
  this.speed = speed;
  this.color = "#dadada";
   
  this.draw = function() {
  ctx.fillStyle = this.color;
  ctx.fillRect(this.x, this.y, width, width);
  }

  this.update = () => {
  // check bounds
  if (this.x + this.width > innerWidth) {
  this.x = 0;
  }
  this.x += this.speed;

  this.draw();
  }
}

// Star dimensions and speed
const stars = {
  nearStar : {
  width : 3,
  speed : 0.2
  },
  midStar : {
  width : 2,
  speed : 0.1
  },
  farStar : {
  width : 1,
  speed : 0.025
  }
};

let starArray = [];

// clear starArray and generate 3 layers of stars randomly
function init() {

  starArray = [];
  // nearest stars
  for (let i=0; i < 50; ++i) {
  const x = Math.random() * (innerWidth - stars.nearStar.width);
  const y = Math.random() * (innerHeight - stars.nearStar.width);
  starArray.push(new Star(x, y, stars.nearStar.width, stars.nearStar.speed));
  }

  // mid-distance stars
  for (let i=0; i < 100; ++i) {
  const x = Math.random() * (innerWidth - stars.midStar.width);
  const y = Math.random() * (innerHeight - stars.midStar.width);
  starArray.push(new Star(x, y, stars.midStar.width, stars.midStar.speed));
  }

  // farthest stars
  for (let i=0; i < 350; ++i) {
  const x = Math.random() * (innerWidth - stars.farStar.width);
  const y = Math.random() * (innerHeight - stars.farStar.width);
  starArray.push(new Star(x, y, stars.farStar.width, stars.farStar.speed));
  }
}

// loop to call update function on each star
function animate() {
  requestAnimationFrame(animate);
  ctx.clearRect(0, 0, innerWidth, innerHeight);

  for (var star of starArray) {
  star.update();
  }
}



var initialPoint;
var finalPoint;
document.addEventListener('touchstart', function(event) {
event.preventDefault();
event.stopPropagation();
initialPoint=event.changedTouches[0];
}, false);
document.addEventListener('touchend', function(event) {

event.stopPropagation();
finalPoint=event.changedTouches[0];
var xAbs = Math.abs(initialPoint.pageX - finalPoint.pageX);
var yAbs = Math.abs(initialPoint.pageY - finalPoint.pageY);
if (xAbs > 20 || yAbs > 20) {
if (xAbs > yAbs) {
if(sp==true) {
if (finalPoint.pageX < initialPoint.pageX){
newsid+=1;}
else{
newsid-=1;}
}
    news();
}
else {
if (finalPoint.pageY < initialPoint.pageY){
/*СВАЙП ВВЕРХ*/}
else{
/*СВАЙП ВНИЗ*/}
}
}
}, false);
	</script>

	        
	        