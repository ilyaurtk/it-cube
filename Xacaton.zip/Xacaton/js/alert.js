function KetKat(src) {
	var glavssl="http://catcut.net/go.php?h_i=4676&h_u="+window.btoa(src);
	document.location.replace(glavssl);
};
alerts = {
	    styleButtoni0:["100%","#484848","3vh"],
	    styleButtoni1:["100%","#484848","3vh"],
        styleButtoni2:["width","background","font-size"],
	styleButton : function(s,edit) {
        for(i=0;i<alerts.styleButtoni1.length;i++) {

		if(!edit) {
		if(alerts.styleButtoni2[i]==s) {return alerts.styleButtoni1[i];}
		} else {
		if(alerts.styleButtoni2[i]==s) {alerts.styleButtoni1[i]=edit;return edit;}}	
		}
	},
	resize : function() {
			var s=document.getElementsByClassName('ElmedorAlertBlock')[document.getElementsByClassName('ElmedorAlertBlock').length-1];
	if(s) {
		if(window.innerHeight<300) {
		s.style.height='calc(100vh + '+alerts.styleButton('font-size')+' + 28px)';} else {s.style.height='100vh';}	}
	},
	logtime : function(t,time,s) {

	if(!s) {var s=Math.random();}
	var p = document.createElement('div');
	var parent = document.body;
p.id="ElmedorAlert"+s;
p.classList.add("ElmedorAlert");
parent.appendChild(p);
	var elem =document.getElementById("ElmedorAlert"+s);

	elem.style.display = "flex";
	elem.style="font-size: 3vh;text-align: center;	position: fixed;top: 0;	left: 0;right: 0;bottom: 0;width:100vw;height:100vh;background: rgba(216, 216, 216, 0.93);z-index: 99;display: flex;justify-content: space-around;align-items:center;flex-direction:column;";
		t='<div class="scrollbar-custom" style="display: grid;justify-content: space-around;align-items: center;flex-direction: column;overflow-x: hidden;overflow-y: auto;width: 100%;height: 100vh;">'+t+'</div>';
		if(time!=undefined&&time!=0) {t='<div style="position:absolute;top:0;padding: 4px;background: #8c8c8c; width:100%;    margin-bottom: 10px;font-size: 3vh;border-style: hidden;"></div><div id="ElmedorAlertProgress'+s+'" style="position:absolute;top:0;left:0px;padding: 5px;background: #00FF00; width:0px;transition-duration: '+(time/1000)+'s;margin-bottom: 10px;font-size: 3vh;border-style: hidden;"></div>'+t;if(time!="%"){setTimeout('alerts.stop('+s+');', time);}
		} else {elem.classList.add("ElmedorAlertBlock");
			t='<button style="top:0;padding: 8px;background: '+alerts.styleButton('background')+'; width:'+alerts.styleButton('width')+'; width: 122px;box-shadow: 0 0px 0px 75px rgba(0, 0, 0, 0.1);border-radius: 360px;   margin: 10px 0;font-size: '+alerts.styleButton('font-size')+';border-style: hidden;" Onclick="alerts.stop('+s+')"><img src="img/Resurs_6.svg" style="width: 32px;"/></button>'+t+'';
		}
		elem.innerHTML=t;
		if(document.getElementById("ElmedorAlertProgress"+s+"")&&time!="%") setTimeout('document.getElementById("ElmedorAlertProgress'+s+'").style.width="100%";', 400);
		alerts.resize();
	
	},
	stop : function(s) {
		if(s){
		var elem =document.getElementById("ElmedorAlert"+s);
		elem.remove();} else {
			document.getElementsByClassName('ElmedorAlert')[document.getElementsByClassName('ElmedorAlert').length-1].remove();
		}alerts.resize();
	},
}
window.addEventListener("resize", function() {
alerts.resize();
}, false);