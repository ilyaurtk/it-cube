<?php 
$to  = "<elmedorru@gmail.com>"; 

$subject = "Вопрос"; 

$message = $_POST["message"];

$headers  = "Content-type: text/html; charset=utf-8 \r\n"; 
$headers .= "From: От кого письмо <".$_POST["name"].">\r\n"; 
$headers .= "Reply-To: ".$_POST["email"]."\r\n"; 

mail($to, $subject, $message, $headers); 
?>
Ваше письмо будет рассмотрено библиотекарем, ожидайте ответа